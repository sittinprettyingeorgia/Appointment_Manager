package Scheduler.database;

/**holds wgu user password for database*/
public class Password {
    private static String password="53689337383";

    /** database password*/
    public static String getPassword(){
        return password;
    }
}
